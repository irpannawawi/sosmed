<?php
 echo form_open_multipart('home/uploadAvatar'); 
 ?>
 
 <input type = "file" name = "pic" >
 <input type = "submit" value = "Upload">
 
 
 <?php echo form_close(); ?>
 <img src = "
 <?php echo $file_url; ?>"  width="320" height="480">