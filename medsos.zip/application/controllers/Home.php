<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function addAvatar($parm = './images/31.jpg'){

		$data = array(
		'title'=>$this->session->name,
		'file_url'=>$parm,
		);
		
		$this->load->view('template/header',$data);
		
		$this->load->view('pages/upload_avatar',$data);
		$this->load->view('template/footer');
		
	}//end method
	
	public function uploadAvatar(){
	
			
			$conf = array(
			'allowed_types'=>'img|jpg|png',
				'max_size'=> 2048,
				'file_name'=>$this->session->id.".jpg",
				'upload_path'=> './images/',
				'overwrite'=>TRUE
				
			);
			$this->upload->initialize($conf);
			if(!$this->upload->do_upload('pic')){
		$data['error'] = $this->upload->display_errors();
		$this->addAvatar();
			}else{


			$preview = $this->upload->data();
			$url= base_url().'/images/'.$preview['file_name'];
			
			
			$this->addAvatar($url);
			}
	
	}//end method
	
	public function post(){
		$data= array('title'=>$this->session->name);
			$this->load->view('pages/home',$data);
	}
	

	public function logout(){
		$sess= array('id','username','name');
		$this->session->unset_userdata($sess);
		redirect('login');
	}
	
}