<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_model {

//inserting new user
	public function insertUser(){
	
	
		$data = array(
		'name' => $this->input->post('name'),
		'username' => $this->input->post('username'),
		 'password' => $this->input->post('password1'),
		 'email' => $this->input->post('email')
		);
			
		$res = $this->db->insert('user',$data);
		
		return $res;
			
			}

//tes duplicate data di db
public function test_username(){
		
		$parm = array(
			'username'=>$this->input->post('username')
		);
		$data = $this->db->get_where('user',$parm);
		return $data->num_rows();
		
}//end test
	public function getUserInfo($username){
		$this->db->where('username',$username);
		$user = $this->db->get('user');
		$data = $user->result_array();
		return $data[0];
	}
	

	//tes login
	public function login($username,$password){
		$data = array('username'=>$username, 'password'=>$password);
		$this->db->where($data);
		$res = $this->db->get('user');
		
		if($res->num_rows()==1){
		
				//set session for user
		$userdata = $this->user_model->getUserInfo($username);
		
		$this->session->userdata('id','name','username');
		$info = array(
				'id'=>$userdata['id'],
				'name'=>$userdata['name'],
				'username'=>$userdata['username']
			);
			$this->session->set_userdata($info);
		//return TRUE
			return TRUE;
		}else{
			return FALSE;
		}
	}//end method
	
	
//end class 
}