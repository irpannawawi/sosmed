<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index($msg=''){
		
		$data= array('title'=>'Login','msg'=>$msg);
			

		$this->load->view('template/header',$data);
		
		$this->load->view('pages/login',$data);
		
		
		
		$this->load->view('template/footer');
	}
	
	public function cek_login(){
		$this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean');
		$this->form_validation->set_rules('password', 'Username', 'required|trim|xss_clean');
		$username= $this->input->post('username');
		$password= $this->input->post('password');
		
		if($this->form_validation->run()==FALSE){
			$this->index();
		}else{
		$auth=	$this->user_model->login($username,$password);
			
		if($auth==TRUE){
				redirect('home/post');
				//true here
			}else{
				$this->index("Invalid username or password !");
			}
			
		}//endif 

	}//end method
}