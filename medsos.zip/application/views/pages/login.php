<?php if($this->session->has_userdata('id')){
redirect('home/post');
	}
?>

<p align="center">
	<?php echo $msg; ?>
</p>

<p align="centre" style="color:red;">
	<?php echo validation_errors(); ?>
</p>

		<?php echo form_open('login/cek_login'); 
		?>
				<table align = "center" class = "table" style = "padding-top:200px;">
						<tr>
								<th>Username</th>
								<td><input 
										type="text"
										class = "form-control"
										name="username" 
										placeholder = "Username">
								</td>
						</tr>
						
						<tr>
								
								<th>
										Password
								</th>
								
								<td>
								<input
										type = "password"
										name = "password"
										placeholder = "********"
										/>
								</td>
								
								
						</tr>
						<tr>
								<td>
									<input
										type = "submit"
										value = "Login"
										
									/>
								</td>
								<td>
										<a 
												href = "<?php echo site_url()."/registration"; ?>"
										>
											Daftar
										</a>
								</td>
						</tr>
						
				</table>
		
		
		<?php echo form_open(); ?>