<div style = "font-size:13px; margin-left: 40%; color:red;">
<?php echo validation_errors(); ?>
</div>


<p style = "color:red; margin-left:40%;" >
	<?php echo $error; ?>
</p>

<?php echo form_open('registration/insert'); ?>
<table  style="border: colapse; padding-top: 20px; text-align:left;" align = "center"cellpadding="2" cellspacing="0">
	<tr>
		<th>
				Full Name
		</th>
		<td>
			<input type="text" name="name" />
		</td>
	</tr>
	
	<tr>
		<th>
			Username
		</th>
		<td>
			<small style="font-size:15px; color:red;">
				*the username use for your user id. it can't use  space and special character. <br>Example : jhon1
			</small><br>
				<input type= "text" name="username" />
		</td>
	</tr>
	<tr>
			<th>Email</th>
			<td>
					<input type="email" placeholder= "example@domain.com" name="email" />
			</td>
	</tr>
	
	<tr>
			<th>Password</th>
			<td>
					<input type="password"placeholder= "********" name="password1"/>
			</td>
	</tr>
	
	<tr>
			<th>Confirm Password</th>
			<td>
					<input type="password" placeholder= "********" name="password2"/>
			</td>
	</tr>
	<tr>
			
			<td colspan="2">
					<input type="submit" value= "Register"/>
			</td>
	</tr>
</table>

<?php echo form_close(); ?>