<?php
	 if(!$this->session->has_userdata('id')){
	redirect('login');
	}
 ?>
 
<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
 <html lang="en">
 <head>
	 <title>MedSos</title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 
	 <link 
	 	rel= "stylesheet"
	 	type = "text/css"
	 	href="style/style.css"
	 />
	 
	 <style type = "text/css">
	
	 .header{
	 	background: #000000;
	 	height: 120px;
	 	margin-left: 80px;
	 	margin-right: 80px;
	 	
	 	color:#ffffff;
	 }
	 
	 .footer{
	 
	 height: 80px;
	 background: orange;
	 margin-left: 80px;
	 margin-right: 80px
	 }
	 .body{
	 min-height: 700px;
	 margin-left: 80px;
	 margin-right: 80px;
	 background :#FAFAFA;
	 }
	 </style>
	 
	 
 </head>
	 <body>
	 
	<div  class="header">
			<h1 style = "padding-top:30px;"><?php echo $title; ?></h1>
			
			<div class = "menu">
					<a href="<?php echo base_url('home/logout'); ?>">Logout</a>
			</div>
			
	</div>
	<div class = "body">

		</div>
	
	<div class  = "footer" >
			
	</div>
	 </body>
 </html>