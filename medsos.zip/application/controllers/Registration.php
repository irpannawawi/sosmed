<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {


		var $data = array('title'=>'Registration',);
		
		//menampilkan halaman registrasi
	public function show_page($error = ''){
	$data= array('error'=>$error);
	$this->load->view('template/header',$this->data);
	$this->load->view('pages/registration',$data);
	$this->load->view('template/footer');
	}


	public function index(){
		
		$this->show_page();
	}
	
	public function insert(){
			$this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean');
			$this->form_validation->set_rules('name', 'Name', 'required|trim|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'required|trim|xss_clean');
			$this->form_validation->set_rules('password1', 'Password', 'required|trim|xss_clean');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'required|trim|xss_clean');
			$pass1 = $this->input->post('password1');
			$pass2 = $this->input->post('password2');
			
			

			
			if($this->form_validation->run() ==FALSE){
			
			$this->show_page();
			 
			}elseif($pass1 != $pass2){
			//tes pass 1 dan pass2 sama/cocok
				$this->show_page('password not match');
			}elseif(strlen($pass1)<6){
			//tes panjang password min 6 karakter
				$this->show_page('Password can\'t less	than 6 character');
			}elseif($this->user_model->test_username()>=1){
			//jika username ada di database
			$this->show_page('Username already exists !');
			
			}else{
				$res = $this->user_model->insertUser();
				if($res==TRUE){
					//show success page
					redirect('login/index/success');
				}else{
				echo "failed";
				}
					
			}
			
	
	}
	
}